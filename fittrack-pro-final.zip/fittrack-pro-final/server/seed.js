const mongoose = require("mongoose");
require("dotenv").config();

const User = require("./models/User");
const Workout = require("./models/Workout");
const Goal = require("./models/Goal");

async function seedDatabase() {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log("Connected to MongoDB for seeding");

    await User.deleteMany();
    await Workout.deleteMany();
    await Goal.deleteMany();

    const sam = await User.create({
      name: "Samuel Cowling",
      email: "samuel@example.com",
      password: "password123",
      age: 21,
      weight: 185,
      fitnessGoal: "Workout 4 times per week"
    });

    const ted = await User.create({
      name: "Ted Lessmann",
      email: "ted@example.com",
      password: "password123",
      age: 21,
      weight: 175,
      fitnessGoal: "Build muscle"
    });

    await Workout.insertMany([
      {
        userId: sam._id,
        exercise: "Bench Press",
        duration: 45,
        sets: 4,
        reps: 8,
        caloriesBurned: 250,
        date: new Date()
      },
      {
        userId: sam._id,
        exercise: "Squats",
        duration: 50,
        sets: 5,
        reps: 5,
        caloriesBurned: 350,
        date: new Date()
      },
      {
        userId: ted._id,
        exercise: "Running",
        duration: 30,
        sets: 0,
        reps: 0,
        caloriesBurned: 300,
        date: new Date()
      }
    ]);

    await Goal.insertMany([
      {
        userId: sam._id,
        title: "Workout Consistency",
        target: "Workout 4 days each week",
        deadline: new Date("2026-08-01"),
        completed: false
      },
      {
        userId: sam._id,
        title: "Strength Goal",
        target: "Bench press 225 pounds",
        deadline: new Date("2026-10-01"),
        completed: false
      },
      {
        userId: ted._id,
        title: "Cardio Goal",
        target: "Run 3 miles without stopping",
        deadline: new Date("2026-09-01"),
        completed: false
      }
    ]);

    console.log("Seed data added successfully");
    console.log("Test accounts:");
    console.log("samuel@example.com / password123");
    console.log("ted@example.com / password123");
    process.exit();
  } catch (error) {
    console.error("Seed error:", error.message);
    process.exit(1);
  }
}

seedDatabase();
