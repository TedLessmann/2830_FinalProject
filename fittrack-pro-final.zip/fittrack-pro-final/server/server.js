const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
require("dotenv").config();

const userRoutes = require("./routes/users");
const workoutRoutes = require("./routes/workouts");
const goalRoutes = require("./routes/goals");

const app = express();

app.use(cors());
app.use(express.json());

app.get("/", (req, res) => {
  res.send("FitTrack Pro API is running");
});

app.use("/api/users", userRoutes);
app.use("/api/workouts", workoutRoutes);
app.use("/api/goals", goalRoutes);

mongoose
  .connect(process.env.MONGO_URI)
  .then(() => {
    console.log("MongoDB connected");
    app.listen(process.env.PORT || 5000, () => {
      console.log(`Server running on port ${process.env.PORT || 5000}`);
    });
  })
  .catch((error) => {
    console.error("MongoDB connection error:", error.message);
  });
