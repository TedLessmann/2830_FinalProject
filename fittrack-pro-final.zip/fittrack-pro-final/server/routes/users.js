const express = require("express");
const router = express.Router();
const User = require("../models/User");

function publicUser(user) {
  return {
    _id: user._id,
    name: user.name,
    email: user.email,
    age: user.age,
    weight: user.weight,
    fitnessGoal: user.fitnessGoal
  };
}

router.post("/register", async (req, res) => {
  try {
    const { name, email, password, age, weight, fitnessGoal } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ message: "Name, email, and password are required" });
    }

    const existingUser = await User.findOne({ email });

    if (existingUser) {
      return res.status(400).json({ message: "An account with this email already exists" });
    }

    const savedUser = await User.create({ name, email, password, age, weight, fitnessGoal });
    res.status(201).json(publicUser(savedUser));
  } catch (error) {
    res.status(500).json({ message: "Error registering user", error: error.message });
  }
});

router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ message: "Email and password are required" });
    }

    const user = await User.findOne({ email });

    if (!user || user.password !== password) {
      return res.status(401).json({ message: "Invalid email or password" });
    }

    res.json(publicUser(user));
  } catch (error) {
    res.status(500).json({ message: "Error logging in", error: error.message });
  }
});

router.get("/", async (req, res) => {
  try {
    const users = await User.find().select("-password").sort({ createdAt: -1 });
    res.json(users);
  } catch (error) {
    res.status(500).json({ message: "Error getting users", error: error.message });
  }
});

router.get("/:id", async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select("-password");
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    res.json(user);
  } catch (error) {
    res.status(500).json({ message: "Error getting user", error: error.message });
  }
});

router.put("/:id", async (req, res) => {
  try {
    const allowedUpdates = {
      name: req.body.name,
      email: req.body.email,
      age: req.body.age,
      weight: req.body.weight,
      fitnessGoal: req.body.fitnessGoal
    };

    Object.keys(allowedUpdates).forEach((key) => {
      if (allowedUpdates[key] === undefined) delete allowedUpdates[key];
    });

    const updatedUser = await User.findByIdAndUpdate(req.params.id, allowedUpdates, {
      new: true,
      runValidators: true
    }).select("-password");

    if (!updatedUser) {
      return res.status(404).json({ message: "User not found" });
    }

    res.json(updatedUser);
  } catch (error) {
    res.status(500).json({ message: "Error updating user", error: error.message });
  }
});

router.delete("/:id", async (req, res) => {
  try {
    const deletedUser = await User.findByIdAndDelete(req.params.id);

    if (!deletedUser) {
      return res.status(404).json({ message: "User not found" });
    }

    res.json({ message: "User deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: "Error deleting user", error: error.message });
  }
});

module.exports = router;
