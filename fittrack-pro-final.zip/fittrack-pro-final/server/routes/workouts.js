const express = require("express");
const router = express.Router();
const Workout = require("../models/Workout");

router.post("/", async (req, res) => {
  try {
    const { userId, exercise, duration, sets, reps, caloriesBurned, date } = req.body;

    if (!userId || !exercise || !duration) {
      return res.status(400).json({ message: "User, exercise, and duration are required" });
    }

    const savedWorkout = await Workout.create({
      userId,
      exercise,
      duration,
      sets,
      reps,
      caloriesBurned,
      date
    });

    res.status(201).json(savedWorkout);
  } catch (error) {
    res.status(500).json({ message: "Error creating workout", error: error.message });
  }
});

router.get("/", async (req, res) => {
  try {
    const { userId } = req.query;

    if (!userId) {
      return res.status(400).json({ message: "userId is required" });
    }

    const workouts = await Workout.find({ userId }).sort({ date: -1 });
    res.json(workouts);
  } catch (error) {
    res.status(500).json({ message: "Error getting workouts", error: error.message });
  }
});

router.put("/:id", async (req, res) => {
  try {
    const updatedWorkout = await Workout.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    });

    if (!updatedWorkout) {
      return res.status(404).json({ message: "Workout not found" });
    }

    res.json(updatedWorkout);
  } catch (error) {
    res.status(500).json({ message: "Error updating workout", error: error.message });
  }
});

router.delete("/:id", async (req, res) => {
  try {
    const deletedWorkout = await Workout.findByIdAndDelete(req.params.id);

    if (!deletedWorkout) {
      return res.status(404).json({ message: "Workout not found" });
    }

    res.json({ message: "Workout deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: "Error deleting workout", error: error.message });
  }
});

module.exports = router;
