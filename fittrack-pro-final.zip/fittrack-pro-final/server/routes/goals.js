const express = require("express");
const router = express.Router();
const Goal = require("../models/Goal");

router.post("/", async (req, res) => {
  try {
    const { userId, title, target, deadline, completed } = req.body;

    if (!userId || !title || !target || !deadline) {
      return res.status(400).json({ message: "User, title, target, and deadline are required" });
    }

    const savedGoal = await Goal.create({ userId, title, target, deadline, completed });
    res.status(201).json(savedGoal);
  } catch (error) {
    res.status(500).json({ message: "Error creating goal", error: error.message });
  }
});

router.get("/", async (req, res) => {
  try {
    const { userId } = req.query;

    if (!userId) {
      return res.status(400).json({ message: "userId is required" });
    }

    const goals = await Goal.find({ userId }).sort({ deadline: 1 });
    res.json(goals);
  } catch (error) {
    res.status(500).json({ message: "Error getting goals", error: error.message });
  }
});

router.put("/:id", async (req, res) => {
  try {
    const updatedGoal = await Goal.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    });

    if (!updatedGoal) {
      return res.status(404).json({ message: "Goal not found" });
    }

    res.json(updatedGoal);
  } catch (error) {
    res.status(500).json({ message: "Error updating goal", error: error.message });
  }
});

router.delete("/:id", async (req, res) => {
  try {
    const deletedGoal = await Goal.findByIdAndDelete(req.params.id);

    if (!deletedGoal) {
      return res.status(404).json({ message: "Goal not found" });
    }

    res.json({ message: "Goal deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: "Error deleting goal", error: error.message });
  }
});

module.exports = router;
