const mongoose = require("mongoose");

const goalSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true
    },
    title: {
      type: String,
      required: [true, "Goal title is required"],
      trim: true
    },
    target: {
      type: String,
      required: [true, "Goal target is required"],
      trim: true
    },
    deadline: {
      type: Date,
      required: [true, "Deadline is required"]
    },
    completed: {
      type: Boolean,
      default: false
    }
  },
  {
    timestamps: true
  }
);

module.exports = mongoose.model("Goal", goalSchema);
