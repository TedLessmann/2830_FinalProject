const mongoose = require("mongoose");

const workoutSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true
    },
    exercise: {
      type: String,
      required: [true, "Exercise name is required"],
      trim: true
    },
    duration: {
      type: Number,
      required: [true, "Duration is required"],
      min: 1
    },
    sets: {
      type: Number,
      default: 0,
      min: 0
    },
    reps: {
      type: Number,
      default: 0,
      min: 0
    },
    caloriesBurned: {
      type: Number,
      default: 0,
      min: 0
    },
    date: {
      type: Date,
      default: Date.now
    }
  },
  {
    timestamps: true
  }
);

module.exports = mongoose.model("Workout", workoutSchema);
