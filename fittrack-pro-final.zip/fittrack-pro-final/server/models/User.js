const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, "Name is required"],
      trim: true
    },
    email: {
      type: String,
      required: [true, "Email is required"],
      trim: true,
      unique: true
    },
    password: {
      type: String,
      required: [true, "Password is required"]
    },
    age: {
      type: Number,
      min: 1
    },
    weight: {
      type: Number,
      min: 1
    },
    fitnessGoal: {
      type: String,
      default: "Build consistency"
    }
  },
  {
    timestamps: true
  }
);

module.exports = mongoose.model("User", userSchema);
