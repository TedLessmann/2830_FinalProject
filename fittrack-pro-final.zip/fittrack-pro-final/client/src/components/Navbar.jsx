import { Link, useNavigate } from "react-router-dom";

function Navbar({ currentUser, onSignOut }) {
  const navigate = useNavigate();

  function handleSignOutClick() {
    onSignOut();
    navigate("/login");
  }

  return (
    <nav className="navbar">
      <h2>FitTrack Pro</h2>

      <div className="nav-links">
        <Link to="/">Home</Link>

        {currentUser ? (
          <>
            <Link to="/dashboard">Dashboard</Link>
            <Link to="/workouts">Workouts</Link>
            <Link to="/goals">Goals</Link>
            <Link to="/profile">Profile</Link>
            <span className="user-name">Logged in as {currentUser.name}</span>
            <button className="signout-btn" onClick={handleSignOutClick}>
              Sign Out
            </button>
          </>
        ) : (
          <Link to="/login">Login</Link>
        )}
      </div>
    </nav>
  );
}

export default Navbar;
