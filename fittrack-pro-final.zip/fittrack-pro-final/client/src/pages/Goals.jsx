import { useEffect, useState } from "react";
import API from "../api";

function Goals({ currentUser }) {
  const [goals, setGoals] = useState([]);
  const [formData, setFormData] = useState({
    title: "",
    target: "",
    deadline: "",
    completed: false
  });
  const [editingId, setEditingId] = useState(null);

  async function fetchGoals() {
    try {
      const response = await API.get(`/goals?userId=${currentUser._id}`);
      setGoals(response.data);
    } catch (error) {
      console.error("Error fetching goals:", error);
    }
  }

  useEffect(() => {
    fetchGoals();
  }, [currentUser._id]);

  function handleChange(event) {
    const { name, value, type, checked } = event.target;
    setFormData({ ...formData, [name]: type === "checkbox" ? checked : value });
  }

  async function handleSubmit(event) {
    event.preventDefault();

    try {
      if (editingId) {
        await API.put(`/goals/${editingId}`, formData);
      } else {
        await API.post("/goals", {
          ...formData,
          userId: currentUser._id
        });
      }

      setFormData({ title: "", target: "", deadline: "", completed: false });
      setEditingId(null);
      fetchGoals();
    } catch (error) {
      alert("Could not save goal. Make sure all fields are filled in.");
    }
  }

  function startEdit(goal) {
    setEditingId(goal._id);
    setFormData({
      title: goal.title,
      target: goal.target,
      deadline: goal.deadline.slice(0, 10),
      completed: goal.completed
    });
  }

  async function deleteGoal(id) {
    try {
      await API.delete(`/goals/${id}`);
      fetchGoals();
    } catch (error) {
      console.error("Error deleting goal:", error);
    }
  }

  async function toggleComplete(goal) {
    try {
      await API.put(`/goals/${goal._id}`, {
        ...goal,
        completed: !goal.completed
      });
      fetchGoals();
    } catch (error) {
      console.error("Error updating goal:", error);
    }
  }

  return (
    <section>
      <h1>Goals</h1>
      <p className="subtle-text">These goals belong to {currentUser.name}.</p>

      <form className="form-card" onSubmit={handleSubmit}>
        <h2>{editingId ? "Edit Goal" : "Add Goal"}</h2>
        <input type="text" name="title" placeholder="Goal title" value={formData.title} onChange={handleChange} />
        <input type="text" name="target" placeholder="Target" value={formData.target} onChange={handleChange} />
        <input type="date" name="deadline" value={formData.deadline} onChange={handleChange} />
        <label className="checkbox-row">
          <input type="checkbox" name="completed" checked={formData.completed} onChange={handleChange} />
          Completed
        </label>
        <button type="submit">{editingId ? "Update Goal" : "Add Goal"}</button>
        {editingId && <button type="button" className="secondary-btn" onClick={() => setEditingId(null)}>Cancel Edit</button>}
      </form>

      <h2>Goal List</h2>
      {goals.length === 0 && <p>No goals yet.</p>}
      {goals.map((goal) => (
        <div className="list-item" key={goal._id}>
          <h3>{goal.title}</h3>
          <p>Target: {goal.target}</p>
          <p>Deadline: {new Date(goal.deadline).toLocaleDateString()}</p>
          <p>Status: {goal.completed ? "Completed" : "In Progress"}</p>
          <button onClick={() => toggleComplete(goal)}>{goal.completed ? "Mark In Progress" : "Mark Complete"}</button>
          <button onClick={() => startEdit(goal)}>Edit</button>
          <button className="delete-btn" onClick={() => deleteGoal(goal._id)}>Delete</button>
        </div>
      ))}
    </section>
  );
}

export default Goals;
