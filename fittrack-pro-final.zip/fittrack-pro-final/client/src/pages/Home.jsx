function Home() {
  return (
    <section className="hero">
      <h1>FitTrack Pro</h1>
      <p>
        FitTrack Pro is a fitness tracking web application that helps users log workouts,
        track fitness goals, and view progress from one dashboard.
      </p>

      <div className="card-grid">
        <div className="card">
          <h3>Login Accounts</h3>
          <p>Register or log in so only one user is active at a time.</p>
        </div>
        <div className="card">
          <h3>Workout Logging</h3>
          <p>Add, edit, and delete workout entries.</p>
        </div>
        <div className="card">
          <h3>Goal Tracking</h3>
          <p>Create fitness goals and mark them complete.</p>
        </div>
      </div>
    </section>
  );
}

export default Home;
