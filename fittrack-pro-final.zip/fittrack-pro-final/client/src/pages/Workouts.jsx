import { useEffect, useState } from "react";
import API from "../api";

function Workouts({ currentUser }) {
  const [workouts, setWorkouts] = useState([]);
  const [formData, setFormData] = useState({
    exercise: "",
    duration: "",
    sets: "",
    reps: "",
    caloriesBurned: ""
  });
  const [editingId, setEditingId] = useState(null);

  async function fetchWorkouts() {
    try {
      const response = await API.get(`/workouts?userId=${currentUser._id}`);
      setWorkouts(response.data);
    } catch (error) {
      console.error("Error fetching workouts:", error);
    }
  }

  useEffect(() => {
    fetchWorkouts();
  }, [currentUser._id]);

  function handleChange(event) {
    const { name, value } = event.target;
    setFormData({ ...formData, [name]: value });
  }

  async function handleSubmit(event) {
    event.preventDefault();

    try {
      if (editingId) {
        await API.put(`/workouts/${editingId}`, formData);
      } else {
        await API.post("/workouts", {
          ...formData,
          userId: currentUser._id
        });
      }

      setFormData({ exercise: "", duration: "", sets: "", reps: "", caloriesBurned: "" });
      setEditingId(null);
      fetchWorkouts();
    } catch (error) {
      alert("Could not save workout. Make sure exercise and duration are filled in.");
    }
  }

  function startEdit(workout) {
    setEditingId(workout._id);
    setFormData({
      exercise: workout.exercise,
      duration: workout.duration,
      sets: workout.sets,
      reps: workout.reps,
      caloriesBurned: workout.caloriesBurned
    });
  }

  async function deleteWorkout(id) {
    try {
      await API.delete(`/workouts/${id}`);
      fetchWorkouts();
    } catch (error) {
      console.error("Error deleting workout:", error);
    }
  }

  return (
    <section>
      <h1>Workouts</h1>
      <p className="subtle-text">These workouts belong to {currentUser.name}.</p>

      <form className="form-card" onSubmit={handleSubmit}>
        <h2>{editingId ? "Edit Workout" : "Add Workout"}</h2>
        <input type="text" name="exercise" placeholder="Exercise name" value={formData.exercise} onChange={handleChange} />
        <input type="number" name="duration" placeholder="Duration in minutes" value={formData.duration} onChange={handleChange} />
        <input type="number" name="sets" placeholder="Sets" value={formData.sets} onChange={handleChange} />
        <input type="number" name="reps" placeholder="Reps" value={formData.reps} onChange={handleChange} />
        <input type="number" name="caloriesBurned" placeholder="Calories burned" value={formData.caloriesBurned} onChange={handleChange} />
        <button type="submit">{editingId ? "Update Workout" : "Add Workout"}</button>
        {editingId && <button type="button" className="secondary-btn" onClick={() => setEditingId(null)}>Cancel Edit</button>}
      </form>

      <h2>Workout History</h2>
      {workouts.length === 0 && <p>No workouts yet.</p>}
      {workouts.map((workout) => (
        <div className="list-item" key={workout._id}>
          <h3>{workout.exercise}</h3>
          <p>Duration: {workout.duration} minutes</p>
          <p>Sets: {workout.sets}</p>
          <p>Reps: {workout.reps}</p>
          <p>Calories Burned: {workout.caloriesBurned}</p>
          <button onClick={() => startEdit(workout)}>Edit</button>
          <button className="delete-btn" onClick={() => deleteWorkout(workout._id)}>Delete</button>
        </div>
      ))}
    </section>
  );
}

export default Workouts;
