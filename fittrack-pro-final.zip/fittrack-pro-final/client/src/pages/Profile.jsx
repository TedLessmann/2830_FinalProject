import { useState } from "react";
import API from "../api";

function Profile({ currentUser, onLogin }) {
  const [formData, setFormData] = useState({
    name: currentUser.name || "",
    email: currentUser.email || "",
    age: currentUser.age || "",
    weight: currentUser.weight || "",
    fitnessGoal: currentUser.fitnessGoal || ""
  });

  function handleChange(event) {
    const { name, value } = event.target;
    setFormData({ ...formData, [name]: value });
  }

  async function handleSubmit(event) {
    event.preventDefault();

    try {
      const response = await API.put(`/users/${currentUser._id}`, formData);
      onLogin(response.data);
      alert("Profile updated successfully");
    } catch (error) {
      alert("Could not update profile");
    }
  }

  return (
    <section>
      <h1>Profile</h1>

      <form className="form-card" onSubmit={handleSubmit}>
        <h2>Your Profile</h2>
        <input type="text" name="name" placeholder="Full name" value={formData.name} onChange={handleChange} />
        <input type="email" name="email" placeholder="Email" value={formData.email} onChange={handleChange} />
        <input type="number" name="age" placeholder="Age" value={formData.age} onChange={handleChange} />
        <input type="number" name="weight" placeholder="Weight" value={formData.weight} onChange={handleChange} />
        <input type="text" name="fitnessGoal" placeholder="Fitness goal" value={formData.fitnessGoal} onChange={handleChange} />
        <button type="submit">Update Profile</button>
      </form>
    </section>
  );
}

export default Profile;
