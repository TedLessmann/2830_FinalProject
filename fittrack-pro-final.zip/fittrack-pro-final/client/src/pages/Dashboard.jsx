import { useEffect, useState } from "react";
import API from "../api";

function Dashboard({ currentUser }) {
  const [workouts, setWorkouts] = useState([]);
  const [goals, setGoals] = useState([]);

  useEffect(() => {
    async function fetchData() {
      try {
        const workoutResponse = await API.get(`/workouts?userId=${currentUser._id}`);
        const goalResponse = await API.get(`/goals?userId=${currentUser._id}`);
        setWorkouts(workoutResponse.data);
        setGoals(goalResponse.data);
      } catch (error) {
        console.error("Error loading dashboard data:", error);
      }
    }

    fetchData();
  }, [currentUser._id]);

  const totalCalories = workouts.reduce((sum, workout) => sum + Number(workout.caloriesBurned || 0), 0);
  const totalMinutes = workouts.reduce((sum, workout) => sum + Number(workout.duration || 0), 0);
  const activeGoals = goals.filter((goal) => !goal.completed).length;

  return (
    <section>
      <h1>Dashboard</h1>
      <p className="subtle-text">Welcome, {currentUser.name}. This dashboard only shows your data.</p>

      <div className="card-grid">
        <div className="stat-card"><h3>Total Workouts</h3><p>{workouts.length}</p></div>
        <div className="stat-card"><h3>Total Minutes</h3><p>{totalMinutes}</p></div>
        <div className="stat-card"><h3>Calories Burned</h3><p>{totalCalories}</p></div>
        <div className="stat-card"><h3>Active Goals</h3><p>{activeGoals}</p></div>
      </div>

      <h2>Recent Workouts</h2>
      {workouts.length === 0 && <p>No workouts yet.</p>}
      {workouts.slice(0, 5).map((workout) => (
        <div className="list-item" key={workout._id}>
          <h3>{workout.exercise}</h3>
          <p>{workout.duration} minutes | {workout.caloriesBurned} calories</p>
        </div>
      ))}
    </section>
  );
}

export default Dashboard;
