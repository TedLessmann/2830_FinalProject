# FitTrack Pro Login Version

This is a practice MERN stack fitness tracker project. It includes account registration, login, sign out, and user-specific workouts/goals.

## Features

- Register account
- Login account
- Sign out
- Only one user logged in at a time using localStorage
- Workouts belong to the logged-in user
- Goals belong to the logged-in user
- CRUD for workouts
- CRUD for goals
- Profile update
- Dashboard totals

## Important

Do not commit or share your real `.env` file. Use `.env.example` as a template.

## Setup

### Server

```bash
cd server
npm install
```

Create a `.env` file in the server folder:

```env
PORT=5000
MONGO_URI=your_mongodb_atlas_connection_string_here
```

Then run:

```bash
npm run seed
npm run dev
```

### Client

Open a second terminal:

```bash
cd client
npm install
npm run dev
```

Open:

```txt
http://localhost:5173
```

## Seed Accounts

```txt
samuel@example.com / password123
ted@example.com / password123
```

## Submission Reminder

Before sending the project to teammates or submitting, remove:

```txt
client/node_modules
server/node_modules
server/.env
```

Keep:

```txt
package.json
package-lock.json
.env.example
```
