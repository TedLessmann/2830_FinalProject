import { useEffect, useState } from 'react';
import api from '../api.js';

function Profile() {
  const [users, setUsers] = useState([]);
  const [form, setForm] = useState({
    name: '',
    email: '',
    password: '',
    weight: '',
    fitnessLevel: 'Beginner'
  });
  const [message, setMessage] = useState('');

  async function loadUsers() {
    const response = await api.get('/users');
    setUsers(response.data);
  }

  useEffect(() => {
    loadUsers().catch(console.error);
  }, []);

  function handleChange(event) {
    setForm({ ...form, [event.target.name]: event.target.value });
  }

  async function handleSubmit(event) {
    event.preventDefault();

    if (!form.name || !form.email || !form.password) {
      setMessage('Name, email, and password are required.');
      return;
    }

    await api.post('/users/register', form);
    setMessage('Profile created.');
    setForm({ name: '', email: '', password: '', weight: '', fitnessLevel: 'Beginner' });
    loadUsers();
  }

  async function deleteUser(id) {
    await api.delete(`/users/${id}`);
    setMessage('Profile deleted.');
    loadUsers();
  }

  return (
    <section>
      <h1>User Profile</h1>
      <form className="form" onSubmit={handleSubmit}>
        <input name="name" placeholder="Name" value={form.name} onChange={handleChange} />
        <input name="email" type="email" placeholder="Email" value={form.email} onChange={handleChange} />
        <input name="password" type="password" placeholder="Password" value={form.password} onChange={handleChange} />
        <input name="weight" type="number" placeholder="Weight" value={form.weight} onChange={handleChange} />
        <select name="fitnessLevel" value={form.fitnessLevel} onChange={handleChange}>
          <option>Beginner</option>
          <option>Intermediate</option>
          <option>Advanced</option>
        </select>
        <button>Create Profile</button>
      </form>

      {message && <p className="message">{message}</p>}

      <h2>Profiles</h2>
      {users.map((user) => (
        <div className="list-item" key={user._id}>
          <div>
            <strong>{user.name}</strong>
            <span>{user.email} • {user.weight} lbs • {user.fitnessLevel}</span>
          </div>
          <button className="danger" onClick={() => deleteUser(user._id)}>Delete</button>
        </div>
      ))}
    </section>
  );
}

export default Profile;
