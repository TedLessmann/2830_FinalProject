function Home() {
  return (
    <section className="hero">
      <h1>FitTrack Pro</h1>
      <p>
        A MERN stack fitness tracking web application for logging workouts,
        tracking fitness goals, and viewing progress in one place.
      </p>
      <div className="card-grid">
        <div className="card"><h3>Workout Logging</h3><p>Add exercises, sets, reps, duration, and calories burned.</p></div>
        <div className="card"><h3>Goal Tracking</h3><p>Create fitness goals and update their progress status.</p></div>
        <div className="card"><h3>Dashboard</h3><p>View totals for workouts, calories burned, and active goals.</p></div>
      </div>
    </section>
  );
}

export default Home;
