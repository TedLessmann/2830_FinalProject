import { useEffect, useState } from 'react';
import api from '../api.js';

function Dashboard() {
  const [workouts, setWorkouts] = useState([]);
  const [goals, setGoals] = useState([]);

  useEffect(() => {
    async function loadData() {
      const workoutResponse = await api.get('/workouts');
      const goalResponse = await api.get('/goals');
      setWorkouts(workoutResponse.data);
      setGoals(goalResponse.data);
    }

    loadData().catch(console.error);
  }, []);

  const totalCalories = workouts.reduce((sum, workout) => sum + Number(workout.caloriesBurned || 0), 0);
  const completedGoals = goals.filter((goal) => goal.status === 'Completed').length;

  return (
    <section>
      <h1>Progress Dashboard</h1>
      <div className="card-grid">
        <div className="card"><h3>Total Workouts</h3><p className="big-number">{workouts.length}</p></div>
        <div className="card"><h3>Calories Burned</h3><p className="big-number">{totalCalories}</p></div>
        <div className="card"><h3>Completed Goals</h3><p className="big-number">{completedGoals}</p></div>
      </div>

      <h2>Recent Workouts</h2>
      {workouts.slice(0, 5).map((workout) => (
        <div className="list-item" key={workout._id}>
          <strong>{workout.exercise}</strong>
          <span>{workout.duration} minutes • {workout.caloriesBurned} calories</span>
        </div>
      ))}
    </section>
  );
}

export default Dashboard;
