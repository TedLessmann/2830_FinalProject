import { useEffect, useState } from 'react';
import api from '../api.js';

const blankWorkout = {
  exercise: '',
  duration: '',
  sets: '',
  reps: '',
  caloriesBurned: ''
};

function Workouts() {
  const [workouts, setWorkouts] = useState([]);
  const [form, setForm] = useState(blankWorkout);
  const [editingId, setEditingId] = useState(null);
  const [message, setMessage] = useState('');

  async function loadWorkouts() {
    const response = await api.get('/workouts');
    setWorkouts(response.data);
  }

  useEffect(() => {
    loadWorkouts().catch(console.error);
  }, []);

  function handleChange(event) {
    setForm({ ...form, [event.target.name]: event.target.value });
  }

  async function handleSubmit(event) {
    event.preventDefault();

    if (!form.exercise || !form.duration) {
      setMessage('Exercise and duration are required.');
      return;
    }

    if (editingId) {
      await api.put(`/workouts/${editingId}`, form);
      setMessage('Workout updated.');
    } else {
      await api.post('/workouts', form);
      setMessage('Workout added.');
    }

    setForm(blankWorkout);
    setEditingId(null);
    loadWorkouts();
  }

  function startEdit(workout) {
    setEditingId(workout._id);
    setForm({
      exercise: workout.exercise,
      duration: workout.duration,
      sets: workout.sets,
      reps: workout.reps,
      caloriesBurned: workout.caloriesBurned
    });
  }

  async function deleteWorkout(id) {
    await api.delete(`/workouts/${id}`);
    setMessage('Workout deleted.');
    loadWorkouts();
  }

  return (
    <section>
      <h1>Workout Logging</h1>
      <form className="form" onSubmit={handleSubmit}>
        <input name="exercise" placeholder="Exercise" value={form.exercise} onChange={handleChange} />
        <input name="duration" type="number" placeholder="Duration minutes" value={form.duration} onChange={handleChange} />
        <input name="sets" type="number" placeholder="Sets" value={form.sets} onChange={handleChange} />
        <input name="reps" type="number" placeholder="Reps" value={form.reps} onChange={handleChange} />
        <input name="caloriesBurned" type="number" placeholder="Calories burned" value={form.caloriesBurned} onChange={handleChange} />
        <button>{editingId ? 'Update Workout' : 'Add Workout'}</button>
      </form>

      {message && <p className="message">{message}</p>}

      <h2>Workout History</h2>
      {workouts.map((workout) => (
        <div className="list-item" key={workout._id}>
          <div>
            <strong>{workout.exercise}</strong>
            <span>{workout.duration} min • Sets: {workout.sets} • Reps: {workout.reps} • Calories: {workout.caloriesBurned}</span>
          </div>
          <div className="button-row">
            <button onClick={() => startEdit(workout)}>Edit</button>
            <button className="danger" onClick={() => deleteWorkout(workout._id)}>Delete</button>
          </div>
        </div>
      ))}
    </section>
  );
}

export default Workouts;
