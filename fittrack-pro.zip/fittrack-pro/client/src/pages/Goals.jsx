import { useEffect, useState } from 'react';
import api from '../api.js';

const blankGoal = {
  title: '',
  target: '',
  status: 'Not Started',
  dueDate: ''
};

function Goals() {
  const [goals, setGoals] = useState([]);
  const [form, setForm] = useState(blankGoal);
  const [editingId, setEditingId] = useState(null);
  const [message, setMessage] = useState('');

  async function loadGoals() {
    const response = await api.get('/goals');
    setGoals(response.data);
  }

  useEffect(() => {
    loadGoals().catch(console.error);
  }, []);

  function handleChange(event) {
    setForm({ ...form, [event.target.name]: event.target.value });
  }

  async function handleSubmit(event) {
    event.preventDefault();

    if (!form.title || !form.target) {
      setMessage('Title and target are required.');
      return;
    }

    if (editingId) {
      await api.put(`/goals/${editingId}`, form);
      setMessage('Goal updated.');
    } else {
      await api.post('/goals', form);
      setMessage('Goal added.');
    }

    setForm(blankGoal);
    setEditingId(null);
    loadGoals();
  }

  function startEdit(goal) {
    setEditingId(goal._id);
    setForm({
      title: goal.title,
      target: goal.target,
      status: goal.status,
      dueDate: goal.dueDate ? goal.dueDate.substring(0, 10) : ''
    });
  }

  async function deleteGoal(id) {
    await api.delete(`/goals/${id}`);
    setMessage('Goal deleted.');
    loadGoals();
  }

  return (
    <section>
      <h1>Goal Tracking</h1>
      <form className="form" onSubmit={handleSubmit}>
        <input name="title" placeholder="Goal title" value={form.title} onChange={handleChange} />
        <input name="target" placeholder="Target" value={form.target} onChange={handleChange} />
        <select name="status" value={form.status} onChange={handleChange}>
          <option>Not Started</option>
          <option>In Progress</option>
          <option>Completed</option>
        </select>
        <input name="dueDate" type="date" value={form.dueDate} onChange={handleChange} />
        <button>{editingId ? 'Update Goal' : 'Add Goal'}</button>
      </form>

      {message && <p className="message">{message}</p>}

      <h2>Your Goals</h2>
      {goals.map((goal) => (
        <div className="list-item" key={goal._id}>
          <div>
            <strong>{goal.title}</strong>
            <span>{goal.target} • {goal.status}</span>
          </div>
          <div className="button-row">
            <button onClick={() => startEdit(goal)}>Edit</button>
            <button className="danger" onClick={() => deleteGoal(goal._id)}>Delete</button>
          </div>
        </div>
      ))}
    </section>
  );
}

export default Goals;
