# FitTrack Pro Practice MERN Project

FitTrack Pro is a practice MERN stack fitness tracking web application. It lets users create profiles, log workouts, track goals, and view progress on a dashboard.

## Stack

- MongoDB
- Express
- React
- Node.js
- Mongoose
- Axios
- React Router

## Features

1. User profile creation and deletion
2. Workout CRUD: create, read, update, delete workouts
3. Goal CRUD: create, read, update, delete goals
4. Dashboard that reads data from the backend and displays totals

## Folder Structure

```txt
fittrack-pro-practice/
├── client/
└── server/
```

## Setup Instructions

### 1. Start MongoDB

Use MongoDB locally or MongoDB Atlas.

For local MongoDB, use this connection string:

```txt
mongodb://127.0.0.1:27017/fittrackpro
```

### 2. Backend Setup

```bash
cd server
npm install
copy .env.example .env
npm run seed
npm run dev
```

On Mac/Linux, use:

```bash
cp .env.example .env
```

The backend runs on:

```txt
http://localhost:5000
```

### 3. Frontend Setup

Open a second terminal:

```bash
cd client
npm install
npm run dev
```

The frontend usually runs on:

```txt
http://localhost:5173
```

## API Routes

### Users

- GET `/api/users`
- POST `/api/users/register`
- POST `/api/users/login`
- PUT `/api/users/:id`
- DELETE `/api/users/:id`

### Workouts

- GET `/api/workouts`
- POST `/api/workouts`
- PUT `/api/workouts/:id`
- DELETE `/api/workouts/:id`

### Goals

- GET `/api/goals`
- POST `/api/goals`
- PUT `/api/goals/:id`
- DELETE `/api/goals/:id`

## How This Meets the Rubric

### Frontend

- Uses React Router for Home, Dashboard, Workouts, Goals, and Profile pages.
- Uses Axios through `src/api.js`.
- Uses `useState` and `useEffect` in multiple pages.
- Includes responsive CSS.

### Backend

- Express server is organized with separate route files.
- Routes handle GET, POST, PUT, and DELETE requests.
- Includes basic input validation and error handling.
- Connects to MongoDB using Mongoose.

### Database

- Uses 3 Mongoose models: User, Workout, and Goal.
- Includes full CRUD for workouts and goals.
- Includes seed data using `seed.js`.

### Integration

React connects to Express with Axios. Express connects to MongoDB with Mongoose. The dashboard reads data from the database and displays it in React.

## Team Member Roles Example

- Drew Doepker: Frontend design, React pages, navigation
- Ted Lessmann: Backend server, Express routes, authentication
- Samuel Cowling: MongoDB models, database setup, testing
- Everyone: Integration, documentation, final testing, presentation

## Important Submission Reminder

Before zipping the project, delete `node_modules` from both the `client` and `server` folders.

Do not submit `node_modules`.
