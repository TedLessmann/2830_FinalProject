const mongoose = require('mongoose');

const workoutSchema = new mongoose.Schema(
  {
    exercise: {
      type: String,
      required: [true, 'Exercise name is required'],
      trim: true
    },
    duration: {
      type: Number,
      required: [true, 'Duration is required'],
      min: 1
    },
    sets: {
      type: Number,
      min: 0,
      default: 0
    },
    reps: {
      type: Number,
      min: 0,
      default: 0
    },
    caloriesBurned: {
      type: Number,
      min: 0,
      default: 0
    },
    date: {
      type: Date,
      default: Date.now
    }
  },
  { timestamps: true }
);

module.exports = mongoose.model('Workout', workoutSchema);
