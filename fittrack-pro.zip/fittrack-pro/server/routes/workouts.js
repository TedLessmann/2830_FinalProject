const express = require('express');
const Workout = require('../models/Workout');

const router = express.Router();

router.get('/', async (req, res) => {
  try {
    const workouts = await Workout.find().sort({ date: -1 });
    res.json(workouts);
  } catch (error) {
    res.status(500).json({ message: 'Error getting workouts', error: error.message });
  }
});

router.post('/', async (req, res) => {
  try {
    const { exercise, duration, sets, reps, caloriesBurned, date } = req.body;

    if (!exercise || !duration) {
      return res.status(400).json({ message: 'Exercise and duration are required' });
    }

    const workout = await Workout.create({ exercise, duration, sets, reps, caloriesBurned, date });
    res.status(201).json(workout);
  } catch (error) {
    res.status(400).json({ message: 'Error creating workout', error: error.message });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const workout = await Workout.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    });

    if (!workout) {
      return res.status(404).json({ message: 'Workout not found' });
    }

    res.json(workout);
  } catch (error) {
    res.status(400).json({ message: 'Error updating workout', error: error.message });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const workout = await Workout.findByIdAndDelete(req.params.id);

    if (!workout) {
      return res.status(404).json({ message: 'Workout not found' });
    }

    res.json({ message: 'Workout deleted' });
  } catch (error) {
    res.status(500).json({ message: 'Error deleting workout', error: error.message });
  }
});

module.exports = router;
