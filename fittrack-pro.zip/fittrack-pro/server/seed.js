const mongoose = require('mongoose');
const dotenv = require('dotenv');
const User = require('./models/User');
const Workout = require('./models/Workout');
const Goal = require('./models/Goal');

dotenv.config();

async function seedDatabase() {
  try {
    await mongoose.connect(process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/fittrackpro');

    await User.deleteMany();
    await Workout.deleteMany();
    await Goal.deleteMany();

    await User.create({
      name: 'Practice User',
      email: 'practice@example.com',
      password: 'password123',
      weight: 180,
      fitnessLevel: 'Beginner'
    });

    await Workout.insertMany([
      { exercise: 'Bench Press', duration: 45, sets: 4, reps: 8, caloriesBurned: 250 },
      { exercise: 'Running', duration: 30, sets: 0, reps: 0, caloriesBurned: 320 },
      { exercise: 'Squats', duration: 50, sets: 5, reps: 5, caloriesBurned: 300 }
    ]);

    await Goal.insertMany([
      { title: 'Workout 4 times per week', target: 'Complete 4 workouts every week', status: 'In Progress' },
      { title: 'Lose 10 pounds', target: 'Reach goal weight by end of semester', status: 'Not Started' }
    ]);

    console.log('Seed data inserted successfully');
    process.exit();
  } catch (error) {
    console.error('Seed error:', error.message);
    process.exit(1);
  }
}

seedDatabase();
